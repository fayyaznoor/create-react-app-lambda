
import React, { useState, useMemo, useEffect } from 'react';
import Header from './components/Header';
import Summary from './components/Summary';
import TransactionForm from './components/TransactionForm';
import TransactionList from './components/TransactionList';
import ExpenseChart from './components/ExpenseChart';
import { Transaction, TransactionType, ExpenseCategory } from './types';

const App: React.FC = () => {
    // Lazy initialization of state from localStorage
    const [transactions, setTransactions] = useState<Transaction[]>(() => {
        const savedTransactions = localStorage.getItem('transactions');
        return savedTransactions ? JSON.parse(savedTransactions) : [];
    });

    // Persist transactions to localStorage whenever they change
    useEffect(() => {
        localStorage.setItem('transactions', JSON.stringify(transactions));
    }, [transactions]);
  
    const addTransaction = (transaction: Omit<Transaction, 'id' | 'date'>) => {
        const newTransaction: Transaction = {
            ...transaction,
            id: crypto.randomUUID(),
            date: new Date().toISOString(),
        };
        setTransactions(prev => [newTransaction, ...prev]);
    };

    const deleteTransaction = (id: string) => {
        setTransactions(prev => prev.filter(tx => tx.id !== id));
    };

    const { totalIncome, totalExpenses, balance } = useMemo(() => {
        let income = 0;
        let expenses = 0;
        transactions.forEach(tx => {
            if (tx.type === TransactionType.INCOME) {
                income += tx.amount;
            } else {
                expenses += tx.amount;
            }
        });
        return {
            totalIncome: income,
            totalExpenses: expenses,
            balance: income - expenses,
        };
    }, [transactions]);

    const expenseChartData = useMemo(() => {
        const expenseData = new Map<ExpenseCategory, number>();
        transactions
            .filter(tx => tx.type === TransactionType.EXPENSE && tx.category)
            .forEach(tx => {
                const currentAmount = expenseData.get(tx.category!) || 0;
                expenseData.set(tx.category!, currentAmount + tx.amount);
            });

        return Array.from(expenseData.entries()).map(([name, value]) => ({ name, value }));
    }, [transactions]);

    return (
        <div className="min-h-screen bg-slate-50">
            <Header />
            <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
                <div className="space-y-8">
                    <Summary totalIncome={totalIncome} totalExpenses={totalExpenses} balance={balance} />
                    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                        <div className="lg:col-span-2 space-y-8">
                            <TransactionForm addTransaction={addTransaction} />
                            <ExpenseChart data={expenseChartData} />
                        </div>
                        <div className="lg:col-span-3">
                            <TransactionList transactions={transactions} deleteTransaction={deleteTransaction} />
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default App;
