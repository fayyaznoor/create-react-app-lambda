
import { GoogleGenAI, Type } from "@google/genai";
import { ExpenseCategory } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const categories = Object.values(ExpenseCategory).join(', ');

export const categorizeExpense = async (description: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Categorize the following business expense for a cosmetics and food company into one of these categories: ${categories}. The expense is: "${description}".`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    category: {
                        type: Type.STRING,
                        description: `The most relevant category for the expense. Must be one of: ${categories}`,
                    },
                },
                required: ['category'],
            },
        },
    });

    const jsonString = response.text;
    const result = JSON.parse(jsonString);
    
    if (result && result.category) {
        // Ensure the returned category is a valid enum value
        const validCategory = Object.values(ExpenseCategory).find(c => c.toLowerCase() === result.category.toLowerCase());
        return validCategory || ExpenseCategory.OTHER;
    }

    return ExpenseCategory.OTHER;
  } catch (error) {
    console.error("Error categorizing expense with Gemini:", error);
    // Fallback to a default category in case of an API error
    return ExpenseCategory.OTHER;
  }
};
