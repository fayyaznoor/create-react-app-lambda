
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ExpenseCategory } from '../types';

interface ExpenseChartProps {
  data: { name: ExpenseCategory; value: number }[];
}

const COLORS = [
  '#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', 
  '#FF1943', '#19A2FF', '#FFB319', '#9C19FF'
];

const ExpenseChart: React.FC<ExpenseChartProps> = ({ data }) => {
  if (data.length === 0) {
    return (
        <div className="bg-white p-6 rounded-2xl shadow-lg h-96 flex items-center justify-center">
            <p className="text-gray-500">No expense data to display.</p>
        </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg h-96">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Expenses by Category</h3>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
            nameKey="name"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value)} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ExpenseChart;
