
import React from 'react';

interface SummaryProps {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
}

const SummaryCard: React.FC<{ title: string; amount: number; color: string }> = ({ title, amount, color }) => {
  const formattedAmount = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg flex-1">
      <h3 className="text-sm font-medium text-gray-500">{title}</h3>
      <p className={`text-3xl font-bold mt-2 ${color}`}>{formattedAmount}</p>
    </div>
  );
};

const Summary: React.FC<SummaryProps> = ({ totalIncome, totalExpenses, balance }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <SummaryCard title="Total Ograii (Income)" amount={totalIncome} color="text-green-500" />
      <SummaryCard title="Total Expenses" amount={totalExpenses} color="text-red-500" />
      <SummaryCard title="Current Balance" amount={balance} color={balance >= 0 ? 'text-blue-600' : 'text-red-600'} />
    </div>
  );
};

export default Summary;
