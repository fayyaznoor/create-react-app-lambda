
import React, { useState, useEffect, useCallback } from 'react';
import { Transaction, TransactionType, ExpenseCategory } from '../types';
import { categorizeExpense } from '../services/geminiService';

interface TransactionFormProps {
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ addTransaction }) => {
  const [type, setType] = useState<TransactionType>(TransactionType.INCOME);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.OTHER);
  const [isCategorizing, setIsCategorizing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleCategorize = useCallback(async () => {
    if (!isOnline || type !== TransactionType.EXPENSE || description.trim().length < 5) return;
    setIsCategorizing(true);
    try {
      const suggestedCategory = await categorizeExpense(description);
      const matchedCategory = Object.values(ExpenseCategory).find(
          c => c.toLowerCase() === suggestedCategory.toLowerCase()
      );
      if (matchedCategory) {
        setCategory(matchedCategory);
      }
    } catch (error) {
      console.error("Error categorizing expense:", error);
    } finally {
      setIsCategorizing(false);
    }
  }, [description, type, isOnline]);

  useEffect(() => {
    const handler = setTimeout(() => {
        handleCategorize();
    }, 1000); // 1-second debounce

    return () => {
      clearTimeout(handler);
    };
  }, [description, handleCategorize]);
  

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (!description || !numericAmount || numericAmount <= 0) {
      alert('Please fill in a valid description and amount.');
      return;
    }

    const newTransaction: Omit<Transaction, 'id' | 'date'> = {
      type,
      description,
      amount: numericAmount,
      category: type === TransactionType.EXPENSE ? category : undefined,
    };

    addTransaction(newTransaction);
    setDescription('');
    setAmount('');
    setCategory(ExpenseCategory.OTHER);
  };
  
  const isIncome = type === TransactionType.INCOME;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Transaction</h3>
      <div className="flex mb-4 rounded-full bg-slate-100 p-1">
          <button onClick={() => setType(TransactionType.INCOME)} className={`w-1/2 py-2 rounded-full text-sm font-semibold transition-colors ${isIncome ? 'bg-green-500 text-white' : 'text-gray-600 hover:bg-slate-200'}`}>
              Ograii (Income)
          </button>
          <button onClick={() => setType(TransactionType.EXPENSE)} className={`w-1/2 py-2 rounded-full text-sm font-semibold transition-colors ${!isIncome ? 'bg-red-500 text-white' : 'text-gray-600 hover:bg-slate-200'}`}>
              Expense
          </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
          <input
            type="text"
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={isIncome ? "e.g., Sales from Batch #123" : "e.g., Purchase of essential oils"}
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-700">Amount</label>
          <input
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        {!isIncome && (
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
            <div className="relative">
                <select
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                >
                    {Object.values(ExpenseCategory).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                    ))}
                </select>
                {isCategorizing && isOnline && (
                     <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                        <svg className="animate-spin h-5 w-5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                )}
                {!isOnline && (
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none" title="You are offline. AI categorization is disabled.">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M17.707 2.293a1 1 0 010 1.414l-14 14a1 1 0 01-1.414-1.414l14-14a1 1 0 011.414 0zM4.414 16.586L2.293 14.465a1 1 0 011.414-1.414l2.121 2.121a1 1 0 01-1.414 1.414zM8.414 12.586L6.293 10.465a1 1 0 011.414-1.414l2.121 2.121a1 1 0 01-1.414 1.414zM12.414 8.586L10.293 6.465a1 1 0 011.414-1.414l2.121 2.121a1 1 0 01-1.414 1.414zM16.414 4.586L14.293 2.465a1 1 0 011.414-1.414l2.121 2.121a1 1 0 01-1.414 1.414z" clipRule="evenodd" />
                        </svg>
                  </div>
                )}
            </div>
            {!isOnline && <p className="mt-2 text-xs text-gray-500">You are offline. Please select a category manually.</p>}
          </div>
        )}
        <button type="submit" className={`w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white transition-colors ${isIncome ? 'bg-green-600 hover:bg-green-700 focus:ring-green-500' : 'bg-red-600 hover:bg-red-700 focus:ring-red-500'} focus:outline-none focus:ring-2 focus:ring-offset-2`}>
          Add Transaction
        </button>
      </form>
    </div>
  );
};

export default TransactionForm;