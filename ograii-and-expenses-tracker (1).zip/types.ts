
export enum TransactionType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE',
}

export enum ExpenseCategory {
  RAW_MATERIALS = 'Raw Materials',
  MARKETING = 'Marketing & Advertising',
  SALARIES = 'Salaries & Wages',
  RENT = 'Rent & Utilities',
  SHIPPING = 'Shipping & Logistics',
  PACKAGING = 'Packaging',
  EQUIPMENT = 'Equipment & Supplies',
  RESEARCH = 'Research & Development',
  OTHER = 'Other',
}

export interface Transaction {
  id: string;
  type: TransactionType;
  description: string;
  amount: number;
  category?: ExpenseCategory;
  date: string;
}
